package com.example.bonedash;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.view.WindowManager.LayoutParams;

/*
 * Prototype only. You must calibrate the swipe path and touch-button coordinates
 * for your own screen/game layout. Android cannot send PC keyboard W/Q inputs
 * directly to Roblox mobile; those must be mapped to on-screen touch controls.
 */
public class MacroAccessibilityService extends AccessibilityService {
    private WindowManager wm;
    private Button trigger;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // PLACEHOLDER calibration values for a 1080x2400 display.
    // Replace with coordinates measured on your actual game screen.
    private static final float TURN_START_X = 760, TURN_START_Y = 1150;
    private static final float TURN_END_X = 320, TURN_END_Y = 1150;
    private static final float DASH_X = 930, DASH_Y = 1450;
    private static final float SKILL_Q_X = 850, SKILL_Q_Y = 2050;

    @Override public void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        trigger = new Button(this);
        trigger.setText("BoneDash");
        trigger.setOnClickListener(v -> runSequence());
        LayoutParams p = new LayoutParams(
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE | LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 24; p.y = 260;
        wm.addView(trigger, p);
    }

    private void runSequence() {
        if (trigger != null) trigger.setEnabled(false);
        // Approximate the PC macro's sequence with touch gestures.
        // The original AHK's W and Q are not mapped automatically:
        // DASH_X/Y and SKILL_Q_X/Y need to be calibrated to in-game buttons.
        swipe(TURN_START_X, TURN_START_Y, TURN_END_X, TURN_END_Y, 220, () ->
            handler.postDelayed(() -> tap(DASH_X, DASH_Y, () ->
                handler.postDelayed(() -> tap(SKILL_Q_X, SKILL_Q_Y, () ->
                    handler.postDelayed(() -> swipe(TURN_END_X, TURN_END_Y,
                        TURN_START_X, TURN_START_Y, 220, () -> {
                            if (trigger != null) trigger.setEnabled(true);
                        }), 80)), 80)), 50));
    }

    private void swipe(float sx, float sy, float ex, float ey, long duration, Runnable done) {
        Path path = new Path();
        path.moveTo(sx, sy); path.lineTo(ex, ey);
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, duration)).build();
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) { if (done != null) done.run(); }
            @Override public void onCancelled(GestureDescription g) { enableTrigger(); }
        }, null);
    }

    private void tap(float x, float y, Runnable done) {
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, 70)).build();
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) { if (done != null) done.run(); }
            @Override public void onCancelled(GestureDescription g) { enableTrigger(); }
        }, null);
    }

    private void enableTrigger() { if (trigger != null) trigger.setEnabled(true); }
    @Override public void onInterrupt() { enableTrigger(); }
    @Override public void onDestroy() {
        if (wm != null && trigger != null) { try { wm.removeView(trigger); } catch (Exception ignored) {} }
        super.onDestroy();
    }
}
