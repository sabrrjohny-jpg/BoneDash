package com.example.bonedash;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        TextView info = new TextView(this);
        info.setText("BoneDash Touch — prototype\n\n1) Enable the accessibility service.\n2) Start the floating trigger.\n3) Configure screen coordinates/timings in MacroAccessibilityService.java before using.\n\nThis is a source prototype, not a ready-made APK. It is not calibrated or tested with Roblox.");
        layout.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));
        Button settings = new Button(this);
        settings.setText("Open Accessibility Settings");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(settings, new LinearLayout.LayoutParams(-1, -2));
        setContentView(layout);
    }
}
